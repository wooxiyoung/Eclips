package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.data.Post;
import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;
import com.peisia.util.Cw;

public class ProcMenuDel {
	static void run() {
		//todo
		//임시
		String read = " 메뉴를 선택하셨습니다";
		Cw.wn("Delete"+read);
		String cmd = Ci.r("삭제할 글 번호");
//		for(Post p:Data.posts) {
//		↑향상된 for문
		int tempSearchIndex = 0;
		for(int i=0;i<Data.posts.size();i=i+1) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex  = i;
			}
		}		
		
		//todo 지우기
		Data.posts.remove(tempSearchIndex);
		Disp.menuMain();
	}
	
}