package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.data.Post;
import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;
import com.peisia.util.Cw;

public class ProcMenuWrite {
	static void run() {
		//todo
		//임시
		String read = " 메뉴를 선택하셨습니다";
		Cw.wn("Write"+read);
		String title;
		
		while(true) {
//			title=Ci.r("글제목");
			title=Ci.rl("글제목");
			if(title.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요");
			}
		}
		String content;
		while(true) {
//			content=Ci.r("글내용");
			content=Ci.rl("글내용");
			if(content.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요");
			}
		}
		String writer;
		while(true) {
			writer=Ci.r("작성자");
			if(writer.length()>0) {
				break;
			}else {
				Cw.wn("다시 입력해주세요");
			}
		}
		
		Post p = new Post(title, content, writer, 0);
		Data.posts.add(p);
		Cw.wn("게시되었습니다.");
		Disp.menuMain();
	}
}
