package com.peisia.c.board.display;

import com.peisia.c.board.Board;
import com.peisia.util.Cw;

public class Disp {
	public static void title() {
		Cw.w("<<<<<<<<");
		Cw.w(Board.TITLE);
		Cw.w(">>>>>>>>");
		Cw.wn();

	}
	public static void menuMain() {
		Cw.wn("-----------------------------------------------");
		Cw.wn("1.List/2.Read/3.Write/4.Delete/5.Edit/6.End");
		Cw.wn("-----------------------------------------------");
	}

}
