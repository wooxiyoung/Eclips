package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.data.Post;
import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;
import com.peisia.util.Cw;

public class ProcMenuEdit {
	static void run() {
		//todo
		//임시
		String read = " 메뉴를 선택하셨습니다";
		Cw.wn("Edit"+read);
		String cmd = Ci.r("수정할 글 번호");
		Disp.menuMain();
}
}