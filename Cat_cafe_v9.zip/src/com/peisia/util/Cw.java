package com.peisia.util;

public class Cw {
	public static void w(String x) {
		System.out.print(x);
	}
	
	public static void wn(String x) {
		System.out.println(x);
	}

}
