package com.peisia.kiosk.catcafe;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
