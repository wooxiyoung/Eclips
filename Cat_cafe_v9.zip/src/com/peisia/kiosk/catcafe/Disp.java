package com.peisia.kiosk.catcafe;

public class Disp {
	public static void Dis() {

		System.out.println("고양이카페 키오스크");
		System.out.println("해당 화면을 클릭해주세요");
	}

	public static void Line() {
		System.out.println("------------------------");
	}
}
