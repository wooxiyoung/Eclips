/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module Cat_cafe {
}