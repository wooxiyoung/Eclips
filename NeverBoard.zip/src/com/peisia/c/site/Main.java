package com.peisia.c.site;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();//기존 게시판에서 site로 확장함. JavaMysqlSitePeisia_v0.0.6
	}
}