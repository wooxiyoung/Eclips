package com.peisia.c.mysqlboard;

import com.peisia.c.mysqlboard.display.DispBoard;
import com.peisia.c.site.SiteMain;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcSecret {
	static public void run() {
		static public final int SECRET_PAGE = 20;
		String firstpage= "select * from board where b_reply_ori"  is null limit "+0+","+SECRET_PAGE;
		DispBoard.titleList();
		DispBoard.bar();
		try {
			Db.result = Db.st.executeQuery(firstpage);
			while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String no = Db.result.getString("b_no");
				String title = Db.result.getString("b_title");
				String id = Db.result.getString("b_id");
				String datetime = Db.result.getString("b_datetime");
				Cw.wn(String.format("%6.6s", no)+"|"+String.format("%-15.12s", title)+"|"+String.format("%15.12s", id)+"|"+String.format("%-15.24s", datetime));
			}
		} catch (Exception e) {
		}
	}
}
