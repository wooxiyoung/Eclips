package com.peisia.c.mysqlboard.display;

import com.peisia.c.util.Cw;

public class DispBoard {
	static private String TITLE = "NEVER";
	static private String VERSION = " ver.0.0";
	static public void Title() {
		Cw.w("==========================================");
		Cw.w(TITLE);
		Cw.w(VERSION);
		Cw.wn("==========================================");
	}
	
	public static void menuMain() {
		Cw.dot();
		Cw.w("[1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [6]검색 [x]게시판 종료");
		Cw.dot();
		Cw.wn();
	}
	static public void titleList() {
		Cw.wn("--------------- 글리스트 ---------------");
		Cw.wn("글번호 글제목 작성자id 작성시간");
	}
	public static void replyBar() {
		Cw.wn("--------------- 댓글 리스트 ---------------");
	}
	
	public static void bar() {
		Cw.wn("---------------------------------------------------------------");
		
	}
	
}